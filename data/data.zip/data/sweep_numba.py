import math
import sys, time
import numpy as np
from numba import cuda
from scipy.spatial.distance import pdist


def make_data(seed, n=12000, p=6000):
    return np.random.default_rng(seed).standard_normal((n, p))


def pca_variance(X, k=10):
    # still on the CPU: BLAS/LAPACK, multi-threaded
    Xc = X - X.mean(axis=0)
    cov = Xc.T @ Xc / (len(Xc) - 1)
    w = np.linalg.eigvalsh(cov)[::-1]
    return w[:k].sum() / w.sum()

def mean_pair_distance_gpu(X, m=800):
    m = min(m, len(X))                  # the kernel must never read beyond the data
    d_X = cuda.to_device(np.ascontiguousarray(X[:m]))      # copy the data to the GPU
    d_out = cuda.device_array(m, dtype=np.float64)         # room for one result per row
    threads = 128
    blocks = (m + threads - 1) // threads
    pair_dist_kernel[blocks, threads](d_X, m, d_out)       # one GPU thread per row
    cuda.synchronize()                    # launches are asynchronous
    return d_out.copy_to_host().sum() / (m * (m - 1) / 2)  # copy the results back

@cuda.jit
def pair_dist_kernel(X, m, out):
    i = cuda.grid(1)                      # global thread index = row number
    if i < m:
        acc = 0.0
        for j in range(i + 1, m):
            s = 0.0
            for k in range(X.shape[1]):
                d = X[i, k] - X[j, k]
                s += d * d
            acc += math.sqrt(s)
        out[i] = acc



if __name__ == "__main__":
    # fail early, with a useful message, if there is no usable GPU
    if not cuda.is_available():
        sys.exit("No usable CUDA GPU: did the job ask for one (--gres), "
                 "and is the numba-cuda module loaded?")
    name = cuda.get_current_device().name
    print("Using GPU:", name.decode() if isinstance(name, bytes) else name)

    seed = int(sys.argv[1])
    t0 = time.perf_counter()
    X = make_data(seed)

    # the first call compiles the kernel and starts the GPU, so check it on a small case
    small = mean_pair_distance_gpu(X, 200)
    if not np.isclose(small, pdist(X[:200]).mean()):
        sys.exit("GPU and SciPy results differ")

    t1 = time.perf_counter()
    dist = mean_pair_distance_gpu(X)
    print(f"pair distances on the GPU: {time.perf_counter() - t1:.2f} s")

    out = (seed, pca_variance(X), dist, time.perf_counter() - t0)
    np.savetxt(f"result_{seed}.csv", [out], delimiter=",")
