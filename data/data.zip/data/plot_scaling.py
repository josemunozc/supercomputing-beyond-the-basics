# plot_scaling.py
import numpy as np
import matplotlib.pyplot as plt

data = np.loadtxt("timings.csv", delimiter=",")       # columns: CPUs, seconds
cpus, secs = data[:, 0], data[:, 1]

# average the repeated runs for each CPU count
n = np.unique(cpus)
t = np.array([secs[cpus == c].mean() for c in n])
speedup = t[n == 1][0] / t

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))

ax1.plot(n, t, "o-")
ax1.set_xlabel("CPUs")
ax1.set_ylabel("time (s)")
ax1.set_title("Run time")

ax2.plot(n, speedup, "o-", label="measured")
ax2.plot(n, n, "--", label="perfect scaling")
ax2.set_yscale("log", base=2)
ax2.set_xlabel("CPUs")
ax2.set_ylabel("speedup")
ax2.set_title("Speedup")
ax2.legend()

fig.tight_layout()
fig.savefig("scaling.png", dpi=150)
plt.show()
