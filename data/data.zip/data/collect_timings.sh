#!/bin/bash

for f in result_42_c*.csv; do
    cpus=${f#result_42_c}          # remove the leading "result_42_c"
    cpus=${cpus%%_*}               # remove everything from the next underscore
    secs=$(cut -d, -f4 "${f}")     # the 4th column is the time in seconds
    echo "${cpus},${secs}"
done | sort -n > timings.csv
