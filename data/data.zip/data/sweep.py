# sweep.py
import sys, time
import numpy as np


# Creates a 3000 × 1500 matrix of random numbers (drawn from a standard normal distribution).
# Uses a seed (passed in from the command line) so the data is reproducible — 
# same seed → same numbers every time.
# This is essential for science: results must be verifiable.
def make_data(seed, n=12000, p=6000):
    return np.random.default_rng(seed).standard_normal((n, p))

# Principal Component Analysis, a dimensionality-reduction technique; 
# useful for summarising many measurements into fewer underlying "factors"
# The function below uses BLAS/LAPACK heavily: threaded and sensitive to CPU kernels
def pca_variance(X, k=10):
    # Centre the data (subtract each column's mean).
    Xc = X - X.mean(axis=0)
    # Build the covariance matrix
    cov = Xc.T @ Xc / (len(Xc) - 1)
    # compute eigenvalues
    w = np.linalg.eigvalsh(cov)[::-1]
    #Return the fraction of total variance explained by the top 10 components
    return w[:k].sum() / w.sum()

# Compute mean pairwise distance 
# Takes the first m rows and computes the average Euclidean distance between every pair of rows 
# deliberately naive loop: single-threaded, vectorise it later
def mean_pair_distance(X, m=800):
    total = 0.0
    for i in range(m):
        for j in range(i + 1, m):
            total += np.sqrt(((X[i] - X[j]) ** 2).sum())
    return total / (m * (m - 1) / 2)

if __name__ == "__main__":
    seed = int(sys.argv[1])
    t0 = time.perf_counter()
    X = make_data(seed)
    out = (seed, pca_variance(X), mean_pair_distance(X), time.perf_counter() - t0)
    np.savetxt(f"result_{seed}.csv", [out], fmt='%6.4f', delimiter=",")
