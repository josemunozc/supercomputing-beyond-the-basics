#!/bin/bash --login
#SBATCH -J sweep-gpu
#SBATCH -o %x.o.%j
#SBATCH -e %x.e.%j
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=8G
#SBATCH --gres=gpu:1
#SBATCH -A <project-code>
#SBATCH -t 00:10:00
#SBATCH -p gpu_v100

set -euo pipefail

module purge
module load SciPy-bundle/2025.07-gfbf-2025b
module load numba-cuda/0.20.0-foss-2025b-CUDA-12.9.1

export OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK}
SEED=${1:-42}

echo "GPU(s) visible to the job: ${CUDA_VISIBLE_DEVICES:-none}"
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv

WORKDIR=/scratch/SCWFXXXXX/${USER}/sweep-gpu/${SLURM_JOB_ID}
mkdir -p "${WORKDIR}"
cp "${SLURM_SUBMIT_DIR}/sweep_numba.py" "${WORKDIR}"
cd "${WORKDIR}"

python sweep_numba.py "${SEED}"

cp "result_${SEED}.csv" "${SLURM_SUBMIT_DIR}/result_${SEED}_gpu_${SLURM_JOB_ID}.csv"
cd "${SLURM_SUBMIT_DIR}"
rm -rf -- "${WORKDIR:?}"
