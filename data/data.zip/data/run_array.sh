#!/bin/bash --login
#SBATCH -J sweep-array
#SBATCH -o logs/%x.o.%A_%a
#SBATCH -e logs/%x.e.%A_%a
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=4G
#SBATCH -A scwf00004_m_einon_2
#SBATCH -t 00:05:00
#SBATCH -p webmo_teaching
#SBATCH --array=1-4

set -euo pipefail

module purge
module load SciPy-bundle/2025.07-gfbf-2025b

export OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK}

# the task number is the seed
SEED=${SLURM_ARRAY_TASK_ID}

# one folder for all the results, one work directory per task on scratch
# and a new directory to keep our log files
RESULTS_DIR=${SLURM_SUBMIT_DIR}/results
WORKDIR=/scratch/SCWF00004/${USER}/sweep-array/${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}
LOGDIR=${SLURM_SUBMIT_DIR}/logs
mkdir -p "${RESULTS_DIR}" "${WORKDIR}" "${LOGDIR}"

cp "${SLURM_SUBMIT_DIR}/sweep_pdist.py" "${WORKDIR}"
cd "${WORKDIR}"

echo "Array ${SLURM_ARRAY_JOB_ID}, task ${SLURM_ARRAY_TASK_ID} (job ${SLURM_JOB_ID}), seed ${SEED}, node $(hostname)"

python sweep_pdist.py "${SEED}"

# copy back with a unique name, then clean up scratch
cp "result_${SEED}.csv" "${RESULTS_DIR}/result_${SEED}_${SLURM_JOB_ID}.csv"
cd "${SLURM_SUBMIT_DIR}"
rm -rf -- "${WORKDIR:?}"
