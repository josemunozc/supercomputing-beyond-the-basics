#!/bin/bash --login
#SBATCH -J sweep-test
#SBATCH -o %x.o.%j
#SBATCH -e %x.e.%j
#SBATCH --ntasks=8
#SBATCH --cpus-per-task=1
#SBATCH --mem=16G
#SBATCH -A scwf00004_m_einon_2
#SBATCH -t 00:05:00
#SBATCH -p webmo_teaching

# give us access to numpy as an extention 
module load SciPy-bundle/2023.07-gfbf-2023a

python sweep.py 42
