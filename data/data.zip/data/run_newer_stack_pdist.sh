#!/bin/bash --login
#SBATCH -J sweep-new-stack-pdist
#SBATCH -o %x.o.%j
#SBATCH -e %x.e.%j
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G
#SBATCH -A scwf00004_m_einon_2
#SBATCH -t 00:05:00
#SBATCH -p webmo_teaching

# stop on errors, unset variables and failures inside pipelines
set -euo pipefail

module purge
module load SciPy-bundle/2025.07-gfbf-2025b

# use the CPUs we asked for (more about this in the next episode)
export OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK}

# the seed is the first argument of the script, 42 if none is given
SEED=${1:-42}

# a unique work directory on scratch for this job
WORKDIR=/scratch/SCWF00004/${USER}/sweep-new-stack-pdist/${SLURM_JOB_ID}
mkdir -p "${WORKDIR}"

# copy inputs to the work directory and change dir
cp "${SLURM_SUBMIT_DIR}/sweep_pdist.py" "${WORKDIR}"
cd "${WORKDIR}"

echo "Job ${SLURM_JOB_ID}: seed ${SEED} on $(hostname) with ${SLURM_CPUS_PER_TASK} CPUs"

# run main program
python sweep_pdist.py "${SEED}"

# copy outputs back, with a unique name
cp "result_${SEED}.csv" "${SLURM_SUBMIT_DIR}/result_${SEED}_c${SLURM_CPUS_PER_TASK}_${SLURM_JOB_ID}.csv"

# clean up scratch (only reached if everything above succeeded)
cd "${SLURM_SUBMIT_DIR}"
rm -rf -- "${WORKDIR:?}"
